let myArray = ["cat"];

let userInput = prompt("Enter a value to add to the array:");

myArray.push(userInput);